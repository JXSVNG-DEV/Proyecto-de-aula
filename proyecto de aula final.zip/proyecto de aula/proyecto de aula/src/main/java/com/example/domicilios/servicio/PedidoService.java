package com.example.domicilios.servicio;

import java.time.LocalDateTime;
import java.util.List;
import java.util.UUID;

import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.example.domicilios.modelo.Cliente;
import com.example.domicilios.modelo.Comprobante;
import com.example.domicilios.modelo.Pedido;
import com.example.domicilios.modelo.Producto;
import com.example.domicilios.repositorio.ClienteRepository;
import com.example.domicilios.repositorio.PedidoRepository;
import com.example.domicilios.repositorio.ProductoRepository;

@Service
@Transactional(readOnly = true)
public class PedidoService {

    /** REGLA 3 · tope de pedidos en curso por cliente. */
    public static final int MAXIMO_EN_CURSO = 3;

    private final PedidoRepository pedidos;
    private final ProductoRepository productos;
    private final ClienteRepository clientes;

    public PedidoService(PedidoRepository pedidos, ProductoRepository productos, ClienteRepository clientes) {
        this.pedidos = pedidos;
        this.productos = productos;
        this.clientes = clientes;
    }

    public List<Pedido> vivos() {
        return pedidos.vivos();
    }

    /** REGLA 5 · vencido = en curso y con más de 45 minutos de espera. */
    public List<Pedido> vencidos() {
        return pedidos.vencidos(LocalDateTime.now().minusMinutes(Pedido.MINUTOS_PLAZO));
    }

    public List<Pedido> deCliente(Long idCliente) {
        Cliente cliente = clientes.findById(idCliente)
                .orElseThrow(() -> new NoEncontradoException("No existe el cliente " + idCliente));
        return pedidos.findByClienteOrderByFechaPedidoDesc(cliente);
    }

    @Transactional
    public Pedido crear(Long idProducto, Long idCliente, int cantidad, String metodoPago) {
        Producto producto = productos.findById(idProducto)
                .orElseThrow(() -> new NoEncontradoException("No existe el producto " + idProducto));
        Cliente cliente = clientes.findById(idCliente)
                .orElseThrow(() -> new NoEncontradoException("No existe el cliente " + idCliente));

        if (cantidad < 1) {
            throw new ReglaNegocioException("La cantidad debe ser al menos 1");
        }
        // REGLA 2 · sin stock suficiente no se puede pedir
        if (producto.getStock() < cantidad) {
            throw new ReglaNegocioException("No hay stock suficiente de «" + producto.getNombre()
                    + "» (quedan " + producto.getStock() + ")");
        }
        // REGLA 3
        if (pedidos.countByClienteAndFechaEntregaIsNull(cliente) >= MAXIMO_EN_CURSO) {
            throw new ReglaNegocioException(
                    cliente.getNombre() + " ya tiene " + MAXIMO_EN_CURSO + " pedidos en curso");
        }

        producto.setStock(producto.getStock() - cantidad);
        Pedido pedido = new Pedido(producto, cliente, cantidad);
        pedido.setTotal(producto.getPrecio() * cantidad);
        pedido.setComprobante(new Comprobante(
                "C-" + UUID.randomUUID().toString().substring(0, 8).toUpperCase(), metodoPago));
        return pedidos.save(pedido);
    }

    @Transactional
    public void entregar(Long idPedido) {
        Pedido pedido = pedidos.findById(idPedido)
                .orElseThrow(() -> new NoEncontradoException("No existe el pedido " + idPedido));
        if (!pedido.estaVivo()) {
            throw new ReglaNegocioException("Ese pedido ya fue entregado");
        }
        pedido.setFechaEntrega(LocalDateTime.now());
    }
}
