package com.example.domicilios.config;

import java.nio.file.Path;

import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Configuration;
import org.springframework.web.servlet.config.annotation.ResourceHandlerRegistry;
import org.springframework.web.servlet.config.annotation.WebMvcConfigurer;


@Configuration
public class WebConfig implements WebMvcConfigurer {

    private final String carpeta;

    public WebConfig(@Value("${domicilios.portadas}") String carpeta) {
        this.carpeta = carpeta;
    }

    @Override
    public void addResourceHandlers(ResourceHandlerRegistry registro) {
        String uri = Path.of(carpeta).toAbsolutePath().normalize().toUri().toString();
        if (!uri.endsWith("/")) {
            uri += "/";
        }
        registro.addResourceHandler("/portadas/**")
                .addResourceLocations(uri, "classpath:/static/img/productos/");
    }
}
