package com.example.domicilios.controlador.dto;

import java.util.List;

import com.example.domicilios.modelo.Negocio;
import com.example.domicilios.modelo.Producto;

public record ProductoDTO(
        Long id,
        String nombre,
        String codigo,
        Double precio,
        Integer stock,
        boolean disponible,
        String categoria,
        List<String> negocios) {

    public static ProductoDTO de(Producto p) {
        return new ProductoDTO(
                p.getId(), p.getNombre(), p.getCodigo(), p.getPrecio(), p.getStock(),
                p.isDisponible(),
                p.getCategoria() == null ? null : p.getCategoria().getNombre(),
                p.getNegocios().stream().map(Negocio::getNombre).sorted().toList());
    }
}
