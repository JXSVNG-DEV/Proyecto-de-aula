package com.example.domicilios.servicio;

import java.io.IOException;
import java.io.InputStream;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.StandardCopyOption;
import java.util.Set;

import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;
import org.springframework.web.multipart.MultipartFile;

@Service
public class StorageService {

    private static final Set<String> TIPOS = Set.of("image/jpeg", "image/png", "image/webp");

    private final Path carpeta;

    public StorageService(@Value("${domicilios.portadas}") String ruta) throws IOException {
        this.carpeta = Path.of(ruta).toAbsolutePath().normalize();
        Files.createDirectories(this.carpeta);
    }
    /** Solo comprueba la foto; no guarda nada. */
public void validar(MultipartFile archivo) {
    if (archivo == null || archivo.isEmpty()) {
        return;
    }
    if (!TIPOS.contains(archivo.getContentType())) {
        throw new ReglaNegocioException("La foto debe ser JPG, PNG o WEBP");
    }
}
    /** Guarda la foto y devuelve el nombre del archivo (lo decide el servidor), o null si no hay. */
    public String guardarPortada(Long idProducto, MultipartFile archivo) {
        if (archivo == null || archivo.isEmpty()) {
            return null;
        }
        if (!TIPOS.contains(archivo.getContentType())) {
            throw new ReglaNegocioException("La foto debe ser JPG, PNG o WEBP");
        }
        String nombre = "producto-" + idProducto + extension(archivo.getContentType());
        try (InputStream in = archivo.getInputStream()) {
            Files.copy(in, carpeta.resolve(nombre), StandardCopyOption.REPLACE_EXISTING);
        } catch (IOException e) {
            throw new ReglaNegocioException("No se pudo guardar la foto");
        }
        return nombre;
    }

    private String extension(String tipo) {
        return switch (tipo) {
            case "image/png" -> ".png";
            case "image/webp" -> ".webp";
            default -> ".jpg";
        };
    }
}
