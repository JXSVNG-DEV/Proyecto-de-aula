package com.example.domicilios.repositorio;

import org.springframework.data.jpa.repository.JpaRepository;
import com.example.domicilios.modelo.Cliente;

public interface ClienteRepository extends JpaRepository<Cliente, Long> {
    boolean existsByEmail(String email);
}
