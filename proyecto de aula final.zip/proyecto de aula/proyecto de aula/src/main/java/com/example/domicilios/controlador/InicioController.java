package com.example.domicilios.controlador;

import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;

import com.example.domicilios.repositorio.ProductoRepository;
import com.example.domicilios.servicio.PedidoService;

@Controller
public class InicioController {

    private final ProductoRepository productos;
    private final PedidoService pedidos;

    public InicioController(ProductoRepository productos, PedidoService pedidos) {
        this.productos = productos;
        this.pedidos = pedidos;
    }

    @GetMapping("/")
    public String inicio(Model modelo) {
        modelo.addAttribute("total", productos.count());
        modelo.addAttribute("ultimos", productos.findTop10ByOrderByIdDesc());
        modelo.addAttribute("porCategoria", productos.contarPorCategoria());
        modelo.addAttribute("vencidos", pedidos.vencidos().size());
        return "inicio";
    }
}
