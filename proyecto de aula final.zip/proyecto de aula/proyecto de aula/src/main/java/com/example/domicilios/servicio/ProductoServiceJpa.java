package com.example.domicilios.servicio;

import java.util.Arrays;
import java.util.HashSet;
import java.util.List;
import java.util.Optional;
import java.util.Set;
import java.util.stream.Collectors;

import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.example.domicilios.modelo.Categoria;
import com.example.domicilios.modelo.Negocio;
import com.example.domicilios.modelo.Producto;
import com.example.domicilios.repositorio.CategoriaRepository;
import com.example.domicilios.repositorio.NegocioRepository;
import com.example.domicilios.repositorio.PedidoRepository;
import com.example.domicilios.repositorio.ProductoRepository;

@Service
@Transactional(readOnly = true)
public class ProductoServiceJpa implements ProductoService {

    private final ProductoRepository productos;
    private final CategoriaRepository categorias;
    private final NegocioRepository negocios;
    private final PedidoRepository pedidos;

    public ProductoServiceJpa(ProductoRepository productos, CategoriaRepository categorias,
                              NegocioRepository negocios, PedidoRepository pedidos) {
        this.productos = productos;
        this.categorias = categorias;
        this.negocios = negocios;
        this.pedidos = pedidos;
    }

    @Override
    public List<Producto> listar() {
        return productos.listarConTodo();
    }

    @Override
    public List<Producto> buscar(String texto) {
        if (texto == null || texto.isBlank()) {
            return listar();   // el buscador vacío no es un error, es "todo"
        }
        return productos.buscarPorNombreONegocio(texto.trim());
    }

    @Override
    public Optional<Producto> porId(Long id) {
        return productos.findById(id);
    }

    @Override
    public Producto obligatorio(Long id) {
        return productos.findById(id)
                .orElseThrow(() -> new NoEncontradoException("No existe el producto " + id));
    }

    // REGLA 1 · el código del producto es único
    @Override
    @Transactional
    public Producto crear(Producto producto, String categoria, String textoNegocios) {
        if (productos.existsByCodigo(producto.getCodigo())) {
            throw new ReglaNegocioException("Ya hay un producto con el código " + producto.getCodigo());
        }
        producto.setCategoria(categoriaPorNombre(categoria));
        producto.setNegocios(negociosPorNombres(textoNegocios));
        return productos.save(producto);
    }

    @Override
    @Transactional
    public Producto editar(Long id, Producto datos, String categoria, String textoNegocios) {
        Producto producto = obligatorio(id);

        productos.findByCodigo(datos.getCodigo())
                .filter(otro -> !otro.getId().equals(id))
                .ifPresent(otro -> {
                    throw new ReglaNegocioException("Ya hay otro producto con ese código");
                });

        producto.setNombre(datos.getNombre());
        producto.setCodigo(datos.getCodigo());
        producto.setPrecio(datos.getPrecio());
        producto.setStock(datos.getStock());
        producto.setCategoria(categoriaPorNombre(categoria));
        producto.setNegocios(negociosPorNombres(textoNegocios));
        return producto;   // dentro de la transacción, el UPDATE sale solo
    }

    // REGLA 4 · un producto con pedidos en curso no se borra
    @Override
    @Transactional
    public void borrar(Long id) {
        Producto producto = obligatorio(id);
        if (pedidos.existsByProductoAndFechaEntregaIsNull(producto)) {
            throw new ReglaNegocioException("No se puede borrar un producto con pedidos en curso");
        }
        if (pedidos.existsByProducto(producto)) {
            throw new ReglaNegocioException("No se puede borrar: el producto tiene historial de pedidos");
        }
        productos.delete(producto);
    }

    @Override
    @Transactional
    public void ponerPortada(Long id, String nombreArchivo) {
        obligatorio(id).setPortada(nombreArchivo);
    }

    private Categoria categoriaPorNombre(String nombre) {
        if (nombre == null || nombre.isBlank()) {
            return null;
        }
        return categorias.findByNombreIgnoreCase(nombre.trim())
                .orElseGet(() -> categorias.save(new Categoria(nombre.trim())));
    }

    private Set<Negocio> negociosPorNombres(String texto) {
        if (texto == null || texto.isBlank()) {
            return new HashSet<>();
        }
        return Arrays.stream(texto.split(","))
                .map(String::trim)
                .filter(n -> !n.isEmpty())
                .map(n -> negocios.findByNombreIgnoreCase(n)
                                  .orElseGet(() -> negocios.save(new Negocio(n))))
                .collect(Collectors.toSet());
    }
}
