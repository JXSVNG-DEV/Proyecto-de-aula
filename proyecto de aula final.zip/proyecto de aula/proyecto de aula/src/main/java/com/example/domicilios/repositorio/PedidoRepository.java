package com.example.domicilios.repositorio;

import java.time.LocalDateTime;
import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;

import com.example.domicilios.modelo.Cliente;
import com.example.domicilios.modelo.Pedido;
import com.example.domicilios.modelo.Producto;

public interface PedidoRepository extends JpaRepository<Pedido, Long> {

    @Query("select p from Pedido p join fetch p.producto join fetch p.cliente left join fetch p.comprobante order by p.fechaPedido desc")
    List<Pedido> todosParaFacturacion();

    @Query("select p from Pedido p join fetch p.producto join fetch p.cliente left join fetch p.comprobante "
         + "where p.cliente.id = :idCliente order by p.fechaPedido desc")
    List<Pedido> facturasDeCliente(@Param("idCliente") Long idCliente);

    long countByClienteAndFechaEntregaIsNull(Cliente cliente);

    boolean existsByProductoAndFechaEntregaIsNull(Producto producto);

    boolean existsByProducto(Producto producto);

    List<Pedido> findByClienteOrderByFechaPedidoDesc(Cliente cliente);

    @Query("""
           select p from Pedido p
           join fetch p.producto
           join fetch p.cliente
           where p.fechaEntrega is null
           order by p.fechaPedido
           """)
    List<Pedido> vivos();

    @Query("""
           select p from Pedido p
           join fetch p.producto
           join fetch p.cliente
           where p.fechaEntrega is null
             and p.fechaPedido < :limite
           order by p.fechaPedido
           """)
    List<Pedido> vencidos(@Param("limite") LocalDateTime limite);
}
