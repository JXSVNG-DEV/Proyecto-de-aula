package com.example.domicilios.controlador.dto;


public record ResumenCliente(Long id, String nombre, String email, long facturas, double total) {
}
