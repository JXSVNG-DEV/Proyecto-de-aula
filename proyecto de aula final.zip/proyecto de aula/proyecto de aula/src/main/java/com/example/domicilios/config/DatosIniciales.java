package com.example.domicilios.config;

import java.time.LocalDateTime;

import org.springframework.boot.CommandLineRunner;
import org.springframework.stereotype.Component;
import org.springframework.transaction.annotation.Transactional;

import com.example.domicilios.modelo.*;
import com.example.domicilios.repositorio.*;

@Component
public class DatosIniciales implements CommandLineRunner {

    private final ProductoRepository productos;
    private final CategoriaRepository categorias;
    private final NegocioRepository negocios;
    private final ClienteRepository clientes;
    private final PedidoRepository pedidos;

    public DatosIniciales(ProductoRepository productos, CategoriaRepository categorias,
                          NegocioRepository negocios, ClienteRepository clientes,
                          PedidoRepository pedidos) {
        this.productos = productos;
        this.categorias = categorias;
        this.negocios = negocios;
        this.clientes = clientes;
        this.pedidos = pedidos;
    }

    @Override
    @Transactional
    public void run(String... args) {
        if (productos.count() > 0) {
            return;   
        }

        Categoria comida = categorias.save(new Categoria("Comida"));
        Categoria bebidas = categorias.save(new Categoria("Bebidas"));
        Categoria postres = categorias.save(new Categoria("Postres"));

        Negocio pizzeria = negocios.save(new Negocio("Pizzería La Heroica"));
        Negocio arepas = negocios.save(new Negocio("Arepas del Centro"));
        Negocio jugos = negocios.save(new Negocio("Jugos Getsemaní"));
        Negocio dulces = negocios.save(new Negocio("Dulces del Portal"));

        Producto pizza = nuevo("Pizza hawaiana", "PIZ-001", 28000.0, 20, comida, pizzeria, "pizza-hawaiana.jpg");
        nuevo("Arepa de huevo", "ARE-001", 6000.0, 40, comida, arepas, "arepa-de-huevo.jpg");
        nuevo("Jugo de lulo", "JUG-001", 7000.0, 30, bebidas, jugos, "jugo-de-lulo.jpg");
        nuevo("Limonada de coco", "JUG-002", 9000.0, 25, bebidas, jugos, "limonada-de-coco.jpg");
        nuevo("Cocada", "DUL-001", 3500.0, 50, postres, dulces, "cocada.jpg");
        nuevo("Pizza de pollo", "PIZ-002", 30000.0, 0, comida, pizzeria, "pizza-de-pollo.jpg");   // agotada

        Cliente ana = clientes.save(new Cliente("Ana Ferrer", "ana@correo.com", "3001234567", "Calle del Arsenal #8-20, Cartagena"));
        clientes.save(new Cliente("Luis Ortega", "luis@correo.com", "3017654321", "Barrio Manga, Cra 21 #25-10, Cartagena"));

        
        Pedido atrasado = new Pedido(pizza, ana, 1);
        atrasado.setTotal(pizza.getPrecio());
        atrasado.setFechaPedido(LocalDateTime.now().minusMinutes(90));
        atrasado.setComprobante(new Comprobante("C-0001", "EFECTIVO"));
        pizza.setStock(pizza.getStock() - 1);
        pedidos.save(atrasado);
    }

    private Producto nuevo(String nombre, String codigo, double precio, int stock,
                       Categoria cat, Negocio negocio, String portada) {
    Producto p = new Producto(nombre, codigo, precio, stock);
    p.setCategoria(cat);
    p.setPortada(portada);
    p.getNegocios().add(negocio);
    return productos.save(p);
}
}
