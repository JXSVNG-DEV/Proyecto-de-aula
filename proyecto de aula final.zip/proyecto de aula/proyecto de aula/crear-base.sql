-- Opcional: la aplicación ya crea la base sola (createDatabaseIfNotExist=true).
CREATE DATABASE IF NOT EXISTS domicilios CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;
