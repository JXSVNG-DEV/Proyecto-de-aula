package com.example.domicilios.servicio;

import java.util.List;
import java.util.Optional;

import com.example.domicilios.modelo.Producto;

public interface ProductoService {
    List<Producto> listar();
    List<Producto> buscar(String texto);
    Optional<Producto> porId(Long id);
    Producto obligatorio(Long id);
    Producto crear(Producto producto, String categoria, String negocios);
    Producto editar(Long id, Producto datos, String categoria, String negocios);
    void borrar(Long id);
    void ponerPortada(Long id, String nombreArchivo);
}
