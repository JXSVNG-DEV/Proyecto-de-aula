package com.example.domicilios.servicio;

import java.util.List;

import org.springframework.data.domain.Sort;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.example.domicilios.modelo.Cliente;
import com.example.domicilios.repositorio.ClienteRepository;

@Service
@Transactional(readOnly = true)
public class ClienteService {

    private final ClienteRepository clientes;

    public ClienteService(ClienteRepository clientes) {
        this.clientes = clientes;
    }

    public List<Cliente> listar() {
        return clientes.findAll(Sort.by("nombre"));
    }

    public Cliente obligatorio(Long id) {
        return clientes.findById(id)
                .orElseThrow(() -> new NoEncontradoException("No existe el cliente " + id));
    }

    @Transactional
    public Cliente crear(Cliente cliente) {
        if (clientes.existsByEmail(cliente.getEmail())) {
            throw new ReglaNegocioException("Ya hay un cliente con ese email");
        }
        return clientes.save(cliente);
    }
}
