package com.example.domicilios.servicio;

/** Lo pedido no se puede hacer: código repetido, sin stock... */
public class ReglaNegocioException extends RuntimeException {
    public ReglaNegocioException(String mensaje) {
        super(mensaje);
    }
}
