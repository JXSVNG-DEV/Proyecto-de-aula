package com.example.domicilios.controlador;

import java.util.LinkedHashMap;
import java.util.stream.Collectors;

import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;

import com.example.domicilios.controlador.dto.ResumenCliente;
import com.example.domicilios.modelo.Pedido;
import com.example.domicilios.repositorio.PedidoRepository;
import com.example.domicilios.servicio.ClienteService;

@Controller
@RequestMapping("/facturacion")
public class FacturacionController {

    private final PedidoRepository pedidos;
    private final ClienteService clientes;

    public FacturacionController(PedidoRepository pedidos, ClienteService clientes) {
        this.pedidos = pedidos;
        this.clientes = clientes;
    }

    
    @GetMapping
    public String facturacion(Model modelo) {
        var lista = pedidos.todosParaFacturacion();
        var resumen = lista.stream()
                .collect(Collectors.groupingBy(p -> p.getCliente().getId(), LinkedHashMap::new, Collectors.toList()))
                .values().stream()
                .map(ps -> new ResumenCliente(
                        ps.get(0).getCliente().getId(),
                        ps.get(0).getCliente().getNombre(),
                        ps.get(0).getCliente().getEmail(),
                        ps.size(),
                        ps.stream().mapToDouble(Pedido::getTotal).sum()))
                .toList();
        modelo.addAttribute("resumen", resumen);
        modelo.addAttribute("totalVentas", lista.stream().mapToDouble(Pedido::getTotal).sum());
        modelo.addAttribute("totalFacturas", lista.size());
        return "facturacion/lista";
    }

    
    @GetMapping("/cliente/{id}")
    public String deCliente(@PathVariable Long id, Model modelo) {
        var lista = pedidos.facturasDeCliente(id);
        modelo.addAttribute("cliente", clientes.obligatorio(id));
        modelo.addAttribute("pedidos", lista);
        modelo.addAttribute("totalCliente", lista.stream().mapToDouble(Pedido::getTotal).sum());
        return "facturacion/cliente";
    }
}
