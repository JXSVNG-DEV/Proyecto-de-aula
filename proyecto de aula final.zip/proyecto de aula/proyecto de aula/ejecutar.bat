@echo off
chcp 65001 >nul
cd /d "%~dp0"
title Domicilios Cartagena
echo ==========================================
echo   Domicilios Cartagena - arranque
echo ==========================================

rem ---------- 1. Java 17 o superior ----------
where java >nul 2>nul
if errorlevel 1 goto sinjava
for /f "tokens=3" %%v in ('java -version 2^>^&1 ^| findstr /i "version"') do set JV=%%~v
for /f "delims=." %%a in ("%JV%") do set JMAJOR=%%a
if %JMAJOR% LSS 17 goto javaviejo
echo [OK] Java %JV%
goto maven

:sinjava
echo [ERROR] No se encontro Java. Instala JDK 17 o superior desde https://adoptium.net
echo         y vuelve a abrir esta ventana.
pause
exit /b 1

:javaviejo
echo [ERROR] Tienes Java %JV% y el proyecto necesita 17 o superior.
echo         Instala JDK 17+ desde https://adoptium.net
pause
exit /b 1

rem ---------- 2. Maven (usa el instalado o lo descarga aqui) ----------
:maven
set MVN=
where mvn >nul 2>nul
if not errorlevel 1 set MVN=mvn
if defined MVN goto mavenok
set MVN=%~dp0.maven\apache-maven-3.9.9\bin\mvn.cmd
if exist "%MVN%" goto mavenok
echo [..] Maven no esta instalado. Descargandolo (una sola vez, ~9 MB)...
if not exist "%~dp0.maven" mkdir "%~dp0.maven"
powershell -NoProfile -Command "[Net.ServicePointManager]::SecurityProtocol=[Net.SecurityProtocolType]::Tls12; Invoke-WebRequest 'https://archive.apache.org/dist/maven/maven-3/3.9.9/binaries/apache-maven-3.9.9-bin.zip' -OutFile '%~dp0.maven\maven.zip'; Expand-Archive '%~dp0.maven\maven.zip' -DestinationPath '%~dp0.maven' -Force"
if not exist "%MVN%" goto fallomaven
del "%~dp0.maven\maven.zip" >nul 2>nul
:mavenok
echo [OK] Maven listo
goto datos

:fallomaven
echo [ERROR] No se pudo descargar Maven. Revisa tu internet o instalalo con:
echo         winget install Apache.Maven
pause
exit /b 1

rem ---------- 3. Usuario y clave de MySQL ----------
:datos
if not defined DB_USER set DB_USER=root
if defined DB_PASSWORD goto arrancar
echo.
echo MySQL debe estar encendido (servicio MySQL80 o XAMPP/WAMP).
set /p DB_PASSWORD=Clave de MySQL para el usuario %DB_USER% (Enter si no tiene): 

rem ---------- 4. Arrancar ----------
:arrancar
echo.
echo Arrancando en http://localhost:8081  (Ctrl+C para detener)
echo.
call "%MVN%" spring-boot:run
echo.
echo La aplicacion se detuvo. Si hubo un error, mira las lineas "Caused by:" arriba.
pause
