package com.example.domicilios.modelo;

import java.util.HashSet;
import java.util.Set;
import java.util.stream.Collectors;

import jakarta.persistence.*;
import jakarta.validation.constraints.*;

@Entity
@Table(name = "productos")
public class Producto {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @NotBlank(message = "El nombre es obligatorio")
    @Column(nullable = false, length = 200)
    private String nombre;

    @NotBlank(message = "El código es obligatorio")
    @Pattern(regexp = "[A-Za-z0-9\\-]{3,20}", message = "Código no válido (3 a 20 letras, números o guiones)")
    @Column(nullable = false, unique = true, length = 20)
    private String codigo;

    @NotNull(message = "El precio es obligatorio")
    @DecimalMin(value = "0.0", inclusive = false, message = "El precio debe ser mayor que 0")
    private Double precio;

    @NotNull(message = "El stock es obligatorio")
    @Min(value = 0, message = "El stock no puede ser negativo")
    private Integer stock;

    private String portada;

    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "categoria_id")
    private Categoria categoria;

    @ManyToMany(fetch = FetchType.LAZY)
    @JoinTable(name = "productos_negocios",
               joinColumns = @JoinColumn(name = "producto_id"),
               inverseJoinColumns = @JoinColumn(name = "negocio_id"))
    private Set<Negocio> negocios = new HashSet<>();

    public Producto() {
    }

    public Producto(String nombre, String codigo, Double precio, Integer stock) {
        this.nombre = nombre;
        this.codigo = codigo;
        this.precio = precio;
        this.stock = stock;
    }

    public boolean isDisponible() {
        return stock != null && stock > 0;
    }

    public String getNegociosComoTexto() {
        return negocios.isEmpty() ? "Sin negocio"
                : negocios.stream().map(Negocio::getNombre).sorted().collect(Collectors.joining(", "));
    }

    public Long getId() { return id; }
    public void setId(Long id) { this.id = id; }

    public String getNombre() { return nombre; }
    public void setNombre(String nombre) { this.nombre = nombre; }

    public String getCodigo() { return codigo; }
    public void setCodigo(String codigo) { this.codigo = codigo; }

    public Double getPrecio() { return precio; }
    public void setPrecio(Double precio) { this.precio = precio; }

    public Integer getStock() { return stock; }
    public void setStock(Integer stock) { this.stock = stock; }

    public String getPortada() { return portada; }
    public void setPortada(String portada) { this.portada = portada; }

    public Categoria getCategoria() { return categoria; }
    public void setCategoria(Categoria categoria) { this.categoria = categoria; }

    public Set<Negocio> getNegocios() { return negocios; }
    public void setNegocios(Set<Negocio> negocios) { this.negocios = negocios; }
}
