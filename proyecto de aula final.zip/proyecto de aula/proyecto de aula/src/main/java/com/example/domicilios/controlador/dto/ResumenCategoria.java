package com.example.domicilios.controlador.dto;


public record ResumenCategoria(String categoria, long total) {
}
