package com.example.domicilios.controlador;

import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.multipart.MaxUploadSizeExceededException;
import org.springframework.web.multipart.MultipartFile;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;

import com.example.domicilios.modelo.Producto;
import com.example.domicilios.servicio.ClienteService;
import com.example.domicilios.servicio.ProductoService;
import com.example.domicilios.servicio.ReglaNegocioException;
import com.example.domicilios.servicio.StorageService;

import jakarta.validation.Valid;

@Controller
@RequestMapping("/productos")
public class ProductoController {

    private final ProductoService servicio;
    private final ClienteService clientes;
    private final StorageService almacen;

    public ProductoController(ProductoService servicio, ClienteService clientes, StorageService almacen) {
        this.servicio = servicio;
        this.clientes = clientes;
        this.almacen = almacen;
    }

    @GetMapping
    public String catalogo(@RequestParam(defaultValue = "") String buscar, Model modelo) {
        modelo.addAttribute("productos", servicio.buscar(buscar));
        modelo.addAttribute("buscar", buscar);
        return "productos/lista";
    }

    @GetMapping("/{id}")
    public String ficha(@PathVariable Long id, Model modelo) {
        modelo.addAttribute("producto", servicio.obligatorio(id));
        modelo.addAttribute("clientes", clientes.listar());
        return "productos/ficha";
    }

    @GetMapping("/{id}/editar")
    public String formularioEditar(@PathVariable Long id, Model modelo) {
        Producto p = servicio.obligatorio(id);
        modelo.addAttribute("producto", p);
        modelo.addAttribute("categoria", p.getCategoria() == null ? "" : p.getCategoria().getNombre());
        modelo.addAttribute("negocios", p.getNegociosComoTexto().replace("Sin negocio", ""));
        return "productos/formulario";
    }

    @PostMapping("/{id}")
    public String editar(@PathVariable Long id,
                         @Valid @ModelAttribute("producto") Producto producto,
                         BindingResult errores,
                         @RequestParam(defaultValue = "") String categoria,
                         @RequestParam(defaultValue = "") String negocios,
                         @RequestParam(required = false) MultipartFile portada,
                         Model modelo,
                         RedirectAttributes flash) {
        producto.setId(id);  
        modelo.addAttribute("categoria", categoria);
        modelo.addAttribute("negocios", negocios);
        if (errores.hasErrors()) {
            return "productos/formulario";
        }
        try {
            servicio.editar(id, producto, categoria, negocios);
            String archivo = almacen.guardarPortada(id, portada);
            if (archivo != null) {
                servicio.ponerPortada(id, archivo);
            }
            flash.addFlashAttribute("aviso", "Cambios guardados");
            return "redirect:/productos/" + id;
        } catch (ReglaNegocioException e) {
            errores.rejectValue("codigo", "duplicado", e.getMessage());
            return "productos/formulario";
        }
    }

    @PostMapping("/{id}/borrar")
    public String borrar(@PathVariable Long id, RedirectAttributes flash) {
        try {
            servicio.borrar(id);
            flash.addFlashAttribute("aviso", "Producto borrado");
        } catch (ReglaNegocioException e) {
            flash.addFlashAttribute("error", e.getMessage());
        }
        return "redirect:/productos";
    }

    @ExceptionHandler(MaxUploadSizeExceededException.class)
    public String fotoGrande(RedirectAttributes flash) {
        flash.addFlashAttribute("error", "La foto no puede pasar de 1 MB");
        return "redirect:/productos";
    }
}
