package com.example.domicilios.repositorio;

import java.util.List;
import java.util.Optional;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;

import com.example.domicilios.controlador.dto.ResumenCategoria;
import com.example.domicilios.modelo.Producto;

public interface ProductoRepository extends JpaRepository<Producto, Long> {

    
    Optional<Producto> findByCodigo(String codigo);

    boolean existsByCodigo(String codigo);

    List<Producto> findByNombreContainingIgnoreCase(String texto);

    List<Producto> findByCategoriaNombreIgnoreCase(String categoria);

    List<Producto> findByStockGreaterThanOrderByNombreAsc(int stock);

    List<Producto> findTop10ByOrderByIdDesc();

    
    @Query("""
           select distinct p from Producto p
           left join p.negocios n
           where lower(p.nombre) like lower(concat('%', :texto, '%'))
              or lower(n.nombre) like lower(concat('%', :texto, '%'))
           order by p.nombre
           """)
    List<Producto> buscarPorNombreONegocio(@Param("texto") String texto);

    
    @Query("""
           select distinct p from Producto p
           left join fetch p.categoria
           left join fetch p.negocios
           order by p.nombre
           """)
    List<Producto> listarConTodo();

    @Query("""
           select new com.example.domicilios.controlador.dto.ResumenCategoria(c.nombre, count(p))
           from Producto p join p.categoria c
           group by c.nombre
           order by count(p) desc
           """)
    List<ResumenCategoria> contarPorCategoria();
}
