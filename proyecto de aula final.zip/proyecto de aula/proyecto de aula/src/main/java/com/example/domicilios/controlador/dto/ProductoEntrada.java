package com.example.domicilios.controlador.dto;

import jakarta.validation.constraints.*;


public record ProductoEntrada(
        @NotBlank String nombre,
        @NotBlank String codigo,
        @NotNull @Positive Double precio,
        @NotNull @Min(0) Integer stock,
        String categoria,
        String negocios) {
}
