package com.example.domicilios.controlador;

import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;

import com.example.domicilios.modelo.Cliente;
import com.example.domicilios.servicio.ClienteService;
import com.example.domicilios.servicio.PedidoService;
import com.example.domicilios.servicio.ReglaNegocioException;

import jakarta.validation.Valid;

@Controller
@RequestMapping("/clientes")
public class ClienteController {

    private final ClienteService clientes;
    private final PedidoService pedidos;

    public ClienteController(ClienteService clientes, PedidoService pedidos) {
        this.clientes = clientes;
        this.pedidos = pedidos;
    }

    @GetMapping
    public String lista(Model modelo) {
        modelo.addAttribute("clientes", clientes.listar());
        modelo.addAttribute("cliente", new Cliente());
        return "clientes/lista";
    }

    @GetMapping("/{id}")
    public String ficha(@PathVariable Long id, Model modelo) {
        modelo.addAttribute("cliente", clientes.obligatorio(id));
        modelo.addAttribute("pedidos", pedidos.deCliente(id));
        return "clientes/ficha";
    }

    @PostMapping
    public String crear(@Valid @ModelAttribute("cliente") Cliente cliente,
                        BindingResult errores,
                        Model modelo,
                        RedirectAttributes flash) {
        if (!errores.hasErrors()) {
            try {
                clientes.crear(cliente);
                flash.addFlashAttribute("aviso", "Cliente registrado");
                return "redirect:/clientes";
            } catch (ReglaNegocioException e) {
                errores.rejectValue("email", "duplicado", e.getMessage());
            }
        }
        modelo.addAttribute("clientes", clientes.listar());
        return "clientes/lista";
    }
}
