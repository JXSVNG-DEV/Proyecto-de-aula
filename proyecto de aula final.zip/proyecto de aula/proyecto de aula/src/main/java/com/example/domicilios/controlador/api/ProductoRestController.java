package com.example.domicilios.controlador.api;

import java.net.URI;
import java.util.List;
import java.util.Map;

import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import com.example.domicilios.controlador.dto.ProductoDTO;
import com.example.domicilios.controlador.dto.ProductoEntrada;
import com.example.domicilios.modelo.Producto;
import com.example.domicilios.servicio.NoEncontradoException;
import com.example.domicilios.servicio.ProductoService;
import com.example.domicilios.servicio.ReglaNegocioException;

import jakarta.validation.Valid;

@RestController
@RequestMapping("/api/productos")
public class ProductoRestController {

    private final ProductoService servicio;

    public ProductoRestController(ProductoService servicio) {
        this.servicio = servicio;
    }

    @GetMapping
    public List<ProductoDTO> listar(@RequestParam(defaultValue = "") String buscar) {
        return servicio.buscar(buscar).stream().map(ProductoDTO::de).toList();
    }

    @GetMapping("/{id}")
    public ResponseEntity<ProductoDTO> uno(@PathVariable Long id) {
        return servicio.porId(id)
                .map(ProductoDTO::de)
                .map(ResponseEntity::ok)
                .orElse(ResponseEntity.notFound().build());   // 404
    }

    @PostMapping
    public ResponseEntity<ProductoDTO> crear(@Valid @RequestBody ProductoEntrada e) {
        Producto creado = servicio.crear(
                new Producto(e.nombre(), e.codigo(), e.precio(), e.stock()), e.categoria(), e.negocios());
        return ResponseEntity
                .created(URI.create("/api/productos/" + creado.getId()))   // 201 + Location
                .body(ProductoDTO.de(creado));
    }

    @PutMapping("/{id}")
    public ProductoDTO editar(@PathVariable Long id, @Valid @RequestBody ProductoEntrada e) {
        return ProductoDTO.de(servicio.editar(id,
                new Producto(e.nombre(), e.codigo(), e.precio(), e.stock()), e.categoria(), e.negocios()));
    }

    @DeleteMapping("/{id}")
    @ResponseStatus(HttpStatus.NO_CONTENT)
    public void borrar(@PathVariable Long id) {
        servicio.borrar(id);   // 204
    }

    @ExceptionHandler(NoEncontradoException.class)
    @ResponseStatus(HttpStatus.NOT_FOUND)
    public Map<String, String> noEncontrado(NoEncontradoException e) {
        return Map.of("error", e.getMessage());
    }

    @ExceptionHandler(ReglaNegocioException.class)
    @ResponseStatus(HttpStatus.CONFLICT)
    public Map<String, String> reglaRota(ReglaNegocioException e) {
        return Map.of("error", e.getMessage());   // 409
    }
}
