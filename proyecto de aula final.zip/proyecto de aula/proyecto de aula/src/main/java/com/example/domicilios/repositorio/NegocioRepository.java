package com.example.domicilios.repositorio;

import java.util.Optional;
import org.springframework.data.jpa.repository.JpaRepository;
import com.example.domicilios.modelo.Negocio;

public interface NegocioRepository extends JpaRepository<Negocio, Long> {
    Optional<Negocio> findByNombreIgnoreCase(String nombre);
}
