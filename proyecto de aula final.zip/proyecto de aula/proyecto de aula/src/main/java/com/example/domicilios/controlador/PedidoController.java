package com.example.domicilios.controlador;

import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;

import com.example.domicilios.servicio.PedidoService;
import com.example.domicilios.servicio.ReglaNegocioException;

@Controller
@RequestMapping("/pedidos")
public class PedidoController {

    private final PedidoService servicio;

    public PedidoController(PedidoService servicio) {
        this.servicio = servicio;
    }

    @GetMapping
    public String lista(Model modelo) {
        modelo.addAttribute("vivos", servicio.vivos());
        modelo.addAttribute("vencidos", servicio.vencidos());
        return "pedidos/lista";
    }

    
    @PostMapping("/crear")
    public String crear(@RequestParam Long idProducto,
                        @RequestParam Long idCliente,
                        @RequestParam(defaultValue = "1") int cantidad,
                        @RequestParam(defaultValue = "EFECTIVO") String metodoPago,
                        RedirectAttributes flash) {
        try {
            servicio.crear(idProducto, idCliente, cantidad, metodoPago);
            flash.addFlashAttribute("aviso", "Pedido registrado");
        } catch (ReglaNegocioException e) {
            flash.addFlashAttribute("error", e.getMessage());
        }
        return "redirect:/productos/" + idProducto;
    }

    @PostMapping("/{id}/entregar")
    public String entregar(@PathVariable Long id, RedirectAttributes flash) {
        try {
            servicio.entregar(id);
            flash.addFlashAttribute("aviso", "Pedido entregado");
        } catch (ReglaNegocioException e) {
            flash.addFlashAttribute("error", e.getMessage());
        }
        return "redirect:/pedidos";
    }
}
