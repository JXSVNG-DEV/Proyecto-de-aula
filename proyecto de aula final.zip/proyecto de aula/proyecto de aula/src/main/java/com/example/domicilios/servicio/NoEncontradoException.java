package com.example.domicilios.servicio;

/** El id pedido no existe. El controlador lo traduce a 404. */
public class NoEncontradoException extends RuntimeException {
    public NoEncontradoException(String mensaje) {
        super(mensaje);
    }
}
